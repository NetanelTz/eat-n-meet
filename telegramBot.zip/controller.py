from model import NumberModelWrapper
import sympy
# script to control operation of view

# define bot token and server
TOKEN = '1787473672:AAGg1IGsQbUA1fQ_xE0FmgA2t0uu7OYBedU'
TELEGRAM_INIT_WEBHOOK_URL = 'https://api.telegram.org/bot{}/setWebhook?url=https://49c2d869c9dc.ngrok.io/message'.format(
    TOKEN)


def is_prime(num):
    if num % 2 == 0 and num != 2:
        return "Come on dude, you know even numbers are not prime!"
    if sympy.isprime(num):
        return "prime"
    return "not prime"


def is_palindrome(num):
    if num == num[::-1]:
        return "palindrome"
    return "not palindrome"


def is_factorial(num):
    i = 1
    while True:
        if num % i == 0:
            num //= i
        else:
            break
        i += 1
    if num == 1:
        return "factorial"
    else:
        return "not factorial"


def is_square_root(num):
    if (num ** 0.5).is_integer():
        return "number has square root"
    return "number has no square root"


class NumberController:
    @classmethod
    def create(cls, num: int):
        NumberModelWrapper.create(num)

    @classmethod
    def get_max(cls):
        return NumberModelWrapper.get_max_val()
