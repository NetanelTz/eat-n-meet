from dataclasses import dataclass
from tinydb import TinyDB, Query
from tinydb.operations import increment

DB_PATH = 'ex9_db.json'
db = TinyDB(DB_PATH)
numbers_table = db.table('NumbersDB')


@dataclass
class Number:
    num: int
    amount: int


class NumberModelWrapper:
    # wrapper number DB
    @classmethod
    def get_max_val(cls):
        """
        return the most searched number/s
        :return:
        """
        all_keys = numbers_table.all()
        max_amount = max(i['amount'] for i in all_keys)
        print(max_amount)
        return ', '.join([i['num'] for i in all_keys if i['amount'] == max_amount])

    @classmethod
    def get_key(cls, num: int):
        """
        return info from db about specific number
        :param num: number we want to search
        :return:
        """
        return numbers_table.search(Query().num.matches(num))

    @classmethod
    def create(cls, num: int):
        """
        create new number in DB or update it
        :param num:
        :return:
        """
        if cls.get_key(num):
            numbers_table.update(increment('amount'), Query().num.matches(num))
        else:
            numbers_table.insert({'num': num, 'amount': 1})
