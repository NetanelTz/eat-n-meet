from urllib import request
import requests
from flask import Flask, Response, request

import controller
from controller import NumberController

app = Flask(__name__)


@app.route('/sanity')
def sanity():
    return "Server is running"


@app.route('/message', methods=["POST"])
def handle_message():
    """
    handle all messages from bot
    :return:
    """
    print("got message")
    msg = (request.get_json()['message']['text']).split(" ")
    cmd = msg[0]
    return_msg = "unknown command"
    if len(msg) == 2:
        parameter = msg[1]
        if msg[1].isnumeric():
            NumberController.create(parameter)
    try:
        if cmd == '/prime':
            return_msg = controller.is_prime(int(parameter))
        elif cmd == '/palindrome':
            return_msg = controller.is_palindrome(parameter)
        elif cmd == '/factorial':
            return_msg = controller.is_factorial(int(parameter))
        elif cmd == '/sqrt':
            return_msg = controller.is_square_root(int(parameter))
        elif cmd == '/popular':
            return_msg = NumberController.get_max()
    except Exception as e:
        return_msg = e
    chat_id = request.get_json()['message']['chat']['id']
    requests.get("https://api.telegram.org/bot{}/sendMessage?chat_id={}&text={}"
                 .format(controller.TOKEN, chat_id, return_msg))
    return Response("success")
